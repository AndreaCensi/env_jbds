.. _reference_index:

*********
Reference
*********

.. currentmodule:: cairo

.. toctree::
   :maxdepth: 2

   constants
   context
   exceptions
   matrix
   paths
   patterns
   surfaces
   text
